/*  clocale.h

    Standard C header file wrapper for _loc.h
*/

/*
 *      C/C++ Run Time Library - Version 10.0
 *
 *      Copyright (c) 1997, 2000 by Inprise Corporation
 *      All Rights Reserved.
 *
 */

/* $Revision:   9.1  $ */

#define  __USING_CNAME__
#include <_loc.h>
#undef   __USING_CNAME__
