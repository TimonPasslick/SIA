#pragma option push -b -a8 -pc -A- /*P_O_Push*/
//+-------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992 - 1999.
//
//  File:      issperr.h
//
//  Contents:  Constant definitions for OLE HRESULT values.
//
//  History:   dd-mmm-yy Author    Comment
//
//--------------------------------------------------------------------------

#pragma message("WARNING: issperr.h is an obsolete header file")
#pragma option pop /*P_O_Pop*/
