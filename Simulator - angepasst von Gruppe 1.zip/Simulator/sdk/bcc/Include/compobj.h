#pragma option push -b -a8 -pc -A- /*P_O_Push*/
//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1999.
//
//  File:       compobj.h
//
//----------------------------------------------------------------------------

#if _MSC_VER > 1000
#pragma once
#endif

#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include objbase.h instead of compobj.h")
#endif /* !RC_INVOKED */

#include <objbase.h>

#pragma option pop /*P_O_Pop*/
